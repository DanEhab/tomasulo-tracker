# Load/Store Execution Flow Diagram

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     INSTRUCTION QUEUE                            │
│  L.D F0, 0(R2)  →  S.D F0, 8(R2)  →  ADD.D F2, F0, F4         │
└─────────────────────────────────────────────────────────────────┘
                              ↓
                    ┌─────────────────┐
                    │   ISSUE LOGIC   │
                    │  (Program Order) │
                    └─────────────────┘
                              ↓
        ┌─────────────────────┼─────────────────────┐
        ↓                     ↓                     ↓
┌──────────────┐     ┌──────────────┐      ┌──────────────┐
│ RESERVATION  │     │    LOAD      │      │    STORE     │
│   STATIONS   │     │   BUFFERS    │      │   BUFFERS    │
│              │     │              │      │              │
│  Add1, Add2  │     │ Load1, Load2 │      │Store1, Store2│
│  Mul1, Mul2  │     │              │      │              │
└──────────────┘     └──────────────┘      └──────────────┘
        ↓                     ↓                     ↓
        └─────────────────────┼─────────────────────┘
                              ↓
                    ┌─────────────────┐
                    │  COMMON DATA    │
                    │   BUS (CDB)     │
                    │  (One per Cycle)│
                    └─────────────────┘
                              ↓
        ┌─────────────────────┼─────────────────────┐
        ↓                     ↓                     ↓
┌──────────────┐     ┌──────────────┐      ┌──────────────┐
│   INTEGER    │     │   FLOATING   │      │    MEMORY    │
│  REGISTERS   │     │   REGISTERS  │      │   & CACHE    │
│  R0-R31      │     │   F0-F31     │      │              │
└──────────────┘     └──────────────┘      └──────────────┘
```

## Load Instruction Execution Flow

```
LOAD: L.D F0, 0(R2)
═══════════════════════════════════════════════════════════════

ISSUE PHASE
┌─────────────────────────────────────────────────────────────┐
│ 1. Allocate free Load Buffer (Load1)                        │
│ 2. Read base register R2                                     │
│    - If R2.qi == null: address = R2.value + 0               │
│    - If R2.qi != null: baseRegisterTag = R2.qi (wait)       │
│ 3. Register renaming: F0.qi = Load1                         │
│ 4. Stage = ADDRESS_CALC                                      │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 1: ADDRESS CALCULATION
┌─────────────────────────────────────────────────────────────┐
│ IF baseRegisterTag != null:                                  │
│   → Wait for CDB to broadcast base register value            │
│   → When received: address = value + offset                  │
│   → baseRegisterTag = null                                   │
│                                                               │
│ WHEN address is ready:                                       │
│   → Proceed to conflict detection                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 2: CONFLICT DETECTION
┌─────────────────────────────────────────────────────────────┐
│ Check all Store Buffers:                                     │
│   FOR each Store in Store Buffers:                           │
│     IF Store.address == Load.address AND                     │
│        Store.instructionId < Load.instructionId AND          │
│        Store.stage != COMPLETED:                             │
│       → RAW HAZARD: Block this cycle                         │
│       → Return (stay in ADDRESS_CALC stage)                  │
│                                                               │
│ IF no conflicts:                                             │
│   → Access cache                                             │
│   → timeRemaining = hit ? hitLatency : missLatency+hitLatency│
│   → Stage = MEMORY_ACCESS                                    │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 3: MEMORY ACCESS
┌─────────────────────────────────────────────────────────────┐
│ EACH CYCLE:                                                  │
│   timeRemaining--                                            │
│                                                               │
│ WHEN timeRemaining == 0:                                     │
│   → value = memory[address]                                  │
│   → Stage = COMPLETED                                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
WRITE RESULT PHASE (CDB)
┌─────────────────────────────────────────────────────────────┐
│ IF Load.stage == COMPLETED AND CDB is free:                 │
│   → Broadcast: tag=Load1, value=memory[address]             │
│   → Update all registers: IF reg.qi == Load1:               │
│       reg.value = value, reg.qi = null                       │
│   → Update all RS: IF rs.qj == Load1: rs.vj = value         │
│   → Update all Buffers waiting for Load1                     │
│   → Free Load1: busy = false                                 │
└─────────────────────────────────────────────────────────────┘
```

## Store Instruction Execution Flow

```
STORE: S.D F0, 8(R2)
═══════════════════════════════════════════════════════════════

ISSUE PHASE
┌─────────────────────────────────────────────────────────────┐
│ 1. Allocate free Store Buffer (Store1)                      │
│ 2. Read base register R2                                     │
│    - If R2.qi == null: address = R2.value + 8               │
│    - If R2.qi != null: baseRegisterTag = R2.qi (wait)       │
│ 3. Read source register F0 (value to store)                 │
│    - If F0.qi == null: value = F0.value                     │
│    - If F0.qi != null: storeValueTag = F0.qi (wait)         │
│ 4. Stage = ADDRESS_CALC                                      │
│ (No register renaming - stores don't write registers)        │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 1: ADDRESS CALCULATION
┌─────────────────────────────────────────────────────────────┐
│ WAIT for BOTH:                                               │
│   1. IF baseRegisterTag != null:                             │
│      → Wait for CDB broadcast                                │
│      → address = broadcasted_value + offset                  │
│                                                               │
│   2. IF storeValueTag != null:                               │
│      → Wait for CDB broadcast                                │
│      → value = broadcasted_value                             │
│                                                               │
│ WHEN both address AND value are ready:                       │
│   → Proceed to conflict detection                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 2: CONFLICT DETECTION
┌─────────────────────────────────────────────────────────────┐
│ Check all Load Buffers (WAR hazard):                         │
│   FOR each Load in Load Buffers:                             │
│     IF Load.address == Store.address AND                     │
│        Load.instructionId < Store.instructionId AND          │
│        Load.stage != COMPLETED:                              │
│       → WAR HAZARD: Block this cycle                         │
│                                                               │
│ Check all Store Buffers (WAW hazard):                        │
│   FOR each OtherStore in Store Buffers:                      │
│     IF OtherStore.address == Store.address AND               │
│        OtherStore.instructionId < Store.instructionId AND    │
│        OtherStore.stage != COMPLETED:                        │
│       → WAW HAZARD: Block this cycle                         │
│                                                               │
│ IF no conflicts:                                             │
│   → Access cache                                             │
│   → timeRemaining = hit ? hitLatency : missLatency+hitLatency│
│   → Stage = MEMORY_ACCESS                                    │
└─────────────────────────────────────────────────────────────┘
                              ↓
EXECUTE PHASE - Stage 3: MEMORY ACCESS
┌─────────────────────────────────────────────────────────────┐
│ EACH CYCLE:                                                  │
│   timeRemaining--                                            │
│                                                               │
│ WHEN timeRemaining == 0:                                     │
│   → memory[address] = value                                  │
│   → Update cache[blockIndex].data if in cache               │
│   → Stage = COMPLETED                                        │
│   → busy = false (no CDB broadcast for stores)              │
│   → Mark instruction as writeResultCycle = currentCycle     │
└─────────────────────────────────────────────────────────────┘
```

## Cache Access Detail

```
accessCache(address, config, state)
═══════════════════════════════════════════════════════════════

Calculate Block Index:
┌─────────────────────────────────────────────────────────────┐
│ blockSize = 16 (example)                                     │
│ blockIndex = floor(address / blockSize)                     │
│                                                               │
│ Example: address = 24                                        │
│   blockIndex = floor(24 / 16) = 1                           │
└─────────────────────────────────────────────────────────────┘
                              ↓
Check Cache:
┌─────────────────────────────────────────────────────────────┐
│ cacheBlock = cache.get(blockIndex)                          │
│                                                               │
│ IF cacheBlock exists AND valid AND tag matches:             │
│   → CACHE HIT                                                │
│   → latency = hitLatency (e.g., 1 cycle)                    │
│                                                               │
│ ELSE:                                                        │
│   → CACHE MISS                                               │
│   → latency = missLatency + hitLatency (e.g., 50 + 1)      │
│   → Fetch block from memory:                                 │
│       blockStartAddr = blockIndex * blockSize               │
│       FOR i = 0 to blockSize-1:                             │
│         blockData[i] = memory[blockStartAddr + i]           │
│   → Store in cache: cache.set(blockIndex, {                 │
│       tag: blockIndex,                                       │
│       data: blockData,                                       │
│       valid: true                                            │
│     })                                                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
Return: { latency, hit }
```

## Memory Conflict Detection Example

```
Timeline of 3 Instructions:
═══════════════════════════════════════════════════════════════

Instruction 0: S.D F2, 0(R1)  [Store to address 0]
Instruction 1: L.D F4, 0(R1)  [Load from address 0]
Instruction 2: S.D F6, 0(R1)  [Store to address 0]


Cycle 1: Store (Inst 0) Issues
┌─────────────────────────────────────────────────────────────┐
│ Store1: busy=true, address=0, value=5.0, stage=ADDR_CALC   │
└─────────────────────────────────────────────────────────────┘

Cycle 2: Load (Inst 1) Issues, Store (Inst 0) Executes
┌─────────────────────────────────────────────────────────────┐
│ Store1: stage=MEMORY_ACCESS, timeRemaining=2                │
│ Load1:  busy=true, address=0, stage=ADDR_CALC              │
│                                                               │
│ Load1 checks conflicts:                                      │
│   → Store1.address (0) == Load1.address (0) ✓              │
│   → Store1.id (0) < Load1.id (1) ✓ (Store is older)        │
│   → Store1.stage != COMPLETED ✓                             │
│   → RAW HAZARD DETECTED! Load1 BLOCKS                       │
└─────────────────────────────────────────────────────────────┘

Cycle 3: Store2 (Inst 2) Issues
┌─────────────────────────────────────────────────────────────┐
│ Store1: stage=MEMORY_ACCESS, timeRemaining=1                │
│ Load1:  STILL BLOCKED by Store1                             │
│ Store2: busy=true, address=0, stage=ADDR_CALC              │
│                                                               │
│ Store2 checks conflicts:                                     │
│   → Store1.address (0) == Store2.address (0) ✓             │
│   → Store1.id (0) < Store2.id (2) ✓ (Store1 is older)      │
│   → Store1.stage != COMPLETED ✓                             │
│   → WAW HAZARD DETECTED! Store2 BLOCKS                      │
└─────────────────────────────────────────────────────────────┘

Cycle 4: Store1 Completes
┌─────────────────────────────────────────────────────────────┐
│ Store1: COMPLETED, writes memory[0] = 5.0, freed            │
│ Load1:  Re-checks conflicts → No conflicts! Proceeds        │
│         stage=MEMORY_ACCESS, timeRemaining=1                │
│ Store2: STILL BLOCKED by Load1                              │
└─────────────────────────────────────────────────────────────┘

Cycle 5: Load1 Completes
┌─────────────────────────────────────────────────────────────┐
│ Load1:  COMPLETED, reads memory[0] = 5.0                    │
│         Broadcasts on CDB: F4 = 5.0                          │
│         Freed                                                │
│ Store2: Re-checks conflicts → No conflicts! Proceeds        │
│         stage=MEMORY_ACCESS, timeRemaining=1                │
└─────────────────────────────────────────────────────────────┘

Cycle 6: Store2 Completes
┌─────────────────────────────────────────────────────────────┐
│ Store2: COMPLETED, writes memory[0] = <F6 value>            │
│         Freed (no CDB broadcast)                             │
└─────────────────────────────────────────────────────────────┘

Final Result: memory[0] = value of F6 (correct! last store wins)
```

## Key Invariants

✅ **Program Order**: Older instructions always execute before newer ones to the same address  
✅ **Atomicity**: Each memory access is atomic (cache handles this)  
✅ **CDB Fairness**: One broadcast per cycle, FIFO order  
✅ **No Deadlock**: Conflicts only block with older ops, which eventually complete  
✅ **Memory Consistency**: Final memory state matches sequential execution  

## Performance Optimization Points

🚀 **Parallel Execution**: Different addresses can execute simultaneously  
🚀 **Out-of-Order**: Instructions can execute out of program order if no hazards  
🚀 **Dynamic Scheduling**: Tomasulo automatically finds parallelism  
🚀 **Cache Exploitation**: Repeated accesses to same block are fast  
